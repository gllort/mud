#include "../std.h"
#include "../interface.h"
#include "../lpc_to_c.h"

int SGI_should_be_shot_for_including_stupid_bugs_in_ar___evidentally_Solaris_isnt_so_hot_either___do_all_SYSV_versions_of_ar_die_on_files_with_no_symbols_QUESTION_MARK;

#ifdef LPC_TO_C
interface_t *interface[] = {
    0
};
#endif
