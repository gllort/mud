#include "spec.h"

    float cos(float);
    float sin(float);
    float tan(float);
    float asin(float);
    float acos(float);
    float atan(float);
    float sqrt(float);
    float log(float);
    float log10(float);
    float pow(float, float);
    float exp(float);
    float floor(float);
    float ceil(float);

