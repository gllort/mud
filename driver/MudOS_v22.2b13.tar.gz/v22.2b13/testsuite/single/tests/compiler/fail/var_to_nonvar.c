TYPETEST

void foo(int x) {
}

void bar() {
    foo( ({ })...);
}
