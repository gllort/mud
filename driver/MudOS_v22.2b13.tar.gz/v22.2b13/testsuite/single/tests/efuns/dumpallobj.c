void do_tests() {
    dumpallobj();
    dumpallobj("/OBJ_DUMP2");
}
