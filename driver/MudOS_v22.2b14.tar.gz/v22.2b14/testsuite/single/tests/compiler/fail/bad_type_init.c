TYPETEST

int x = "hi";
