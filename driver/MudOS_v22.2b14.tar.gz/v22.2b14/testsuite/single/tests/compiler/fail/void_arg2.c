void foo(void, int bar);
